import React from "react";
import { Box, Button, Paper, Stack } from "@mui/material";
import SubOrder from "./SubOrder";

const Order = ({ order }) => {
  return (
    <Box sx={{ padding: "1rem" }}>
      <Paper>
        <Stack
          p={1}
          alignItems={"center"}
          justifyContent={"space-between"}
          direction={"row"}
          gap={3}
        >
          <Box sx={{ fontWeight: "bold" }}>Table : {order.table_id}</Box>
          <Box sx={{ fontWeight: "bold" }}>Order id : {order.order_id}</Box>
          <Box sx={{ fontWeight: "bold" }}>
            Timer : <span style={{ color: "#c4c4c4" }}>{order.timer}</span>
          </Box>
        </Stack>
        <Stack
          p={1}
          gap={2}
          alignItems={"center"}
          justifyContent={"space-between"}
          direction={"row"}
        >
          <Box
            sx={{
              background: "#61b2e4",
              padding: "0.5rem 4rem",
              color: "#fff",
              fontWeight: "bold",
              borderRadius: "0.5rem",
            }}
          >
            {order.status}
          </Box>
          <Box sx={{ fontWeight: "bold" }}>
            Order time :{" "}
            <span style={{ color: "#c4c4c4" }}>{order.order_time}</span>
          </Box>
        </Stack>
        {order.subOrders.map((item, index) => {
          return <SubOrder key={index} subOrder={item} />;
        })}
      </Paper>
      <Paper sx={{ margin: "1rem 0" }}>
        <button
          style={{
            color: "#fff",
            fontWeight: "bold",
            backgroundColor: "#dc0d28",
            width: "100%",
            outline: "none",
            border: "none",
            padding: "0.7rem ",
            margin: "2rem 0  0",
            borderRadius: "5px",
            transition: "0.2s",
          }}
        >
          Ok
        </button>
      </Paper>
    </Box>
  );
};

export default Order;
