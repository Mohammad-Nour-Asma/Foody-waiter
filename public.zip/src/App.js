import "./App.css";
import { Box, Grid, Typography } from "@mui/material";

import Order from "./components/Order";

function App() {
  const order = {
    table_id: 1,
    order_id: "#2165",
    timer: "12Min",
    status: "New",
    order_time: "12:00 pm",
    subOrders: [
      {
        name: "Burger mac beef",
        amount: "3",
        note: "lorem ipsum ukiwn ont in ioqn ",
        ingre: [
          { name: "tomatto", amount: "3" },
          { name: "bannan", amount: "3" },
          { name: "chess", amount: "5 " },
        ],
        delete_ingre: ["first", "chess", "ssn"],
      },
      {
        name: "Salade",
        amount: "2",
        note: "lorem ipsum ukiwn ont in ioqn ",
        ingre: [
          { name: "tomatto", amount: "3" },
          { name: "bannan", amount: "3" },
          { name: "chess", amount: "5 " },
        ],
        delete_ingre: ["first", "chess", "ssn"],
      },
    ],
  };

  return (
    <Box
      sx={{
        minHeight: "100vh",
        padding: "2rem 1rem",
      }}
    >
      <Typography m={"0 3rem 3rem"} textAlign={"center"} variant="h4">
        Orders
      </Typography>
      <Grid justifyContent={"center"} gap={4} container>
        <Grid item md={4} sm={6} xs={12}>
          <Order order={order} />
        </Grid>
        <Grid item md={4} sm={6} xs={12}>
          <Order order={order} />
        </Grid>
        <Grid item md={4} sm={6} xs={12}>
          <Order order={order} />
        </Grid>
        <Grid item md={4} sm={6} xs={12}>
          <Order order={order} />
        </Grid>
        <Grid item md={4} sm={6} xs={12}>
          <Order order={order} />
        </Grid>
        <Grid item md={4} sm={6} xs={12}>
          <Order order={order} />
        </Grid>
        <Grid item md={4} sm={6} xs={12}>
          <Order order={order} />
        </Grid>
        <Grid item md={4} sm={6} xs={12}>
          <Order order={order} />
        </Grid>
      </Grid>
    </Box>
  );
}

export default App;
